<?php wp_footer(); ?>
</div>
<!-- End Wrapper -->
<?php if ( of_get_option('tracking_code') ) { echo '<script type="text/javascript">'.of_get_option('tracking_code').'</script>'."\n"; } ?>
</body></html>